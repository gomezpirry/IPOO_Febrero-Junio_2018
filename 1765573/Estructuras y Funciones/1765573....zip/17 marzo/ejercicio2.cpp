#include <iostream>
#include <string>
#include <cctype>
#include <cstdlib>


/*Samus Aran cuenta con el power suit, el cual tiene un analizador de da�no basado en
los golpes que recibe. El power suit cuenta con un programa que recibe un arreglo de
enumeraciones, donde cada enumeraci�on representa un golpe recibido. Cada golpe tiene
un nivel de da�no y le resta puntos de energia como se indica a continuaci�on:
MORDEDURA = 50
PUNETAZO = 100 �
ESPADAZO = 150
RAYO = 200
EXPLOSION = 300
Defina una funci�on que reciba el nivel de energia inicial, la cantidad de golpes recibidos
y un arreglo de enumeraciones con las secuencia de golpes que recibio el power suit, y
retorne el nivel de energ�ia restante desp�ues de recibir los golpes
 */
 
 using namespace std;
 
 
 enum golpes  {
 	
 	mordedura = 50,
 	punetazo = 100,
 	espadazo = 150, 
 	rayo = 200,
 	explosion = 300,
 
}
	 
	 
	 	
	 	golpes  combo [5] ={mordedura, punetazo, espadazo, rayo,explosion};
	 	
	 
	 	
	 	for(int i=0; i < cantidadGolpes; i++){
	 		energiaInicial -= secuenciaGolpes[golpe];
	 		
		 }
	
	 	return energia inicial; 	
	 		
	 		
		 }
		 
		 
int main(){
	
	int energia = 1000; 
	golpes secuenciaGolpes [10] = {mordedura, punetazo, mordedura,explosion};
	
	int golpes sizeof (secuenciaGolpes)/sizeof(secuenciaGolpes);
		int danoRecibido (int energiaInicial, int cantidadGolpes, golpes secuenciaGolpes[]);
	
	
	cout<<"Energia Restante es: "<<energiaRestante;
	 }
	
	
	


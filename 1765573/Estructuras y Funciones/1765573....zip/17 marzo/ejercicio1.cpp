#include <iostream>

#include <iostream>
#include <string>
#include <cctype>
#include <cstdlib>
/*1. Se requiere un programa que retorne el mayor o el menor valor de un arreglo. La funci�on
puede recibir un arreglo de flotantes o de enteros a ordenar (use sobrecarga) y el tama�no
del arreglo. Tambi�en recibe un booleano para indicar si se desea buscar el mayor (true)
o el menor (false); por defecto la funci�on buscar�a el mayor
*/

float obtenerMm (float arreglo[],int Y,bool mayor = true){

	
	int valor = arreglo[0]{
	for (int i =0; i<Y;i++)
	if (arreglo[i]<valor)}
	valor =arreglo[i];
	else;
}
int obtenerMm (int arreglo[],int Y,bool mayor = true){

	
	int valor = arreglo[0]{
	for (int i =0; i<Y;i++)
	if (arreglo[i]<valor)}
	else; 
}
 int main(){
 	
 	
 	float valor[5]={1.5,1.4,3.5,4.5,3.5};
 	int valor [5]={4,5,6,7,8};
 	
 	
 

return valor; 
}
}
